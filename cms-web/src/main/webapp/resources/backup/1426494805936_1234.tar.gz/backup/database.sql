-- MySQL dump 10.13  Distrib 5.1.72, for Win64 (unknown)
--
-- Host: localhost    Database: cms
-- ------------------------------------------------------
-- Server version	5.1.72-community

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `t_attachment`
--

DROP TABLE IF EXISTS `t_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_attachment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `old_name` varchar(255) DEFAULT NULL,
  `new_name` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `suffix` varchar(255) DEFAULT NULL,
  `size` bigint(100) DEFAULT NULL,
  `is_index_pic` int(11) DEFAULT NULL,
  `is_img` int(11) DEFAULT NULL,
  `t_id` int(11) DEFAULT NULL,
  `is_attach` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `t_id` (`t_id`),
  CONSTRAINT `t_attachment_ibfk_2` FOREIGN KEY (`t_id`) REFERENCES `t_topic` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_attachment`
--

LOCK TABLES `t_attachment` WRITE;
/*!40000 ALTER TABLE `t_attachment` DISABLE KEYS */;
INSERT INTO `t_attachment` VALUES (10,'may be me','1426256021733.jpg','application/octet-stream','jpg',173878,0,1,18,0);
/*!40000 ALTER TABLE `t_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_channel`
--

DROP TABLE IF EXISTS `t_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_channel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `custom_link` int(11) DEFAULT '0',
  `custom_link_url` varchar(255) DEFAULT '#',
  `type` int(11) DEFAULT NULL,
  `is_index` int(11) DEFAULT '0',
  `is_top_nav` int(11) DEFAULT '0',
  `recommend` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `orders` int(11) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  CONSTRAINT `t_channel_ibfk_1` FOREIGN KEY (`pid`) REFERENCES `t_channel` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_channel`
--

LOCK TABLES `t_channel` WRITE;
/*!40000 ALTER TABLE `t_channel` DISABLE KEYS */;
INSERT INTO `t_channel` VALUES (1,'用户管理模块',0,'#',1,0,0,0,1,1,NULL),(2,'用户管理1',0,'#',1,0,0,0,1,1,1),(3,'用户管理2',0,'#',1,0,0,0,1,2,1),(4,'用户管理3',0,'#',1,0,0,0,1,3,1),(5,'用户管理4',0,'#',1,0,0,0,1,4,1),(6,'文章管理模块',0,'#',0,0,0,0,1,2,NULL),(7,'文章管理1',0,'#',1,0,0,0,1,1,6),(8,'文章管理2',0,'#',1,0,0,0,1,2,6),(9,'文章管理3',0,'#',1,0,0,0,1,3,6),(10,'文章管理4',0,'#',1,0,0,0,1,4,6),(11,'系统管理模块',0,'#',2,0,0,0,1,3,NULL),(12,'系统管理1',0,'#',1,0,0,0,1,1,11),(13,'系统管理2',0,'#',1,0,0,0,1,2,11),(14,'系统管理3',0,'#',1,0,0,0,1,3,11),(15,'系统管理4',0,'#',1,0,0,0,1,4,11),(16,'招生管理模块',0,'#',1,0,0,0,1,4,NULL),(17,'招生管理1',0,'#',1,0,0,0,1,1,16),(18,'招生管理2',0,'#',1,0,0,0,1,2,16),(19,'招生管理3',0,'#',1,0,0,0,1,3,16),(20,'招生管理4',0,'#',1,0,0,0,1,4,16);
/*!40000 ALTER TABLE `t_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_group`
--

DROP TABLE IF EXISTS `t_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `descr` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_group`
--

LOCK TABLES `t_group` WRITE;
/*!40000 ALTER TABLE `t_group` DISABLE KEYS */;
INSERT INTO `t_group` VALUES (1,'财务处','负责财务部门的网页'),(2,'计科系','负责财务部门的网页'),(3,'宣传部','负责财务部门的网页');
/*!40000 ALTER TABLE `t_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_group_channel`
--

DROP TABLE IF EXISTS `t_group_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_group_channel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `g_id` int(11) DEFAULT NULL,
  `c_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `g_id` (`g_id`),
  KEY `c_id` (`c_id`),
  CONSTRAINT `t_group_channel_ibfk_1` FOREIGN KEY (`g_id`) REFERENCES `t_group` (`id`),
  CONSTRAINT `t_group_channel_ibfk_2` FOREIGN KEY (`c_id`) REFERENCES `t_channel` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_group_channel`
--

LOCK TABLES `t_group_channel` WRITE;
/*!40000 ALTER TABLE `t_group_channel` DISABLE KEYS */;
INSERT INTO `t_group_channel` VALUES (4,1,6),(5,1,8),(6,2,11),(7,2,12),(8,2,13),(9,2,16),(10,2,17),(11,2,18),(12,3,7),(13,3,6),(16,1,1),(17,1,2),(18,1,3),(19,1,5),(20,1,16),(21,1,19),(22,1,11),(23,1,13),(24,1,14),(25,1,27);
/*!40000 ALTER TABLE `t_group_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_keyword`
--

DROP TABLE IF EXISTS `t_keyword`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_keyword` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `times` int(11) DEFAULT NULL,
  `name_full_py` varchar(255) DEFAULT NULL,
  `name_short_py` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_keyword`
--

LOCK TABLES `t_keyword` WRITE;
/*!40000 ALTER TABLE `t_keyword` DISABLE KEYS */;
INSERT INTO `t_keyword` VALUES (11,'时间',1,'shijian','sj'),(12,'观点',1,'guandian','gd'),(13,'创意',1,'chuangyi','cy'),(14,'文艺',1,'wenyi','wy'),(15,'悲伤',2,'beishang','bs'),(16,'冰激凌',2,'bingjiling','bjl'),(17,'我',1,'wo','w'),(18,'你',1,'ni','n'),(19,'他',1,'ta','t'),(20,'fdf',1,'fdf',''),(21,'告别',1,'gaobie','gb'),(22,'离殇',1,'lishang','ls'),(23,'伤感',1,'shanggan','sg');
/*!40000 ALTER TABLE `t_keyword` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_role`
--

DROP TABLE IF EXISTS `t_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `role_type` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_role`
--

LOCK TABLES `t_role` WRITE;
/*!40000 ALTER TABLE `t_role` DISABLE KEYS */;
INSERT INTO `t_role` VALUES (1,'管理员','ROLE_ADMIN'),(2,'文章发布人员','ROLE_PUBLISH'),(3,'文章审核人员','ROLE_AUDIT');
/*!40000 ALTER TABLE `t_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_topic`
--

DROP TABLE IF EXISTS `t_topic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_topic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `keyword` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `recommend` int(11) DEFAULT NULL,
  `content` longtext,
  `summary` varchar(255) DEFAULT NULL,
  `channel_pic_id` int(11) DEFAULT NULL,
  `publish_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `create_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `c_id` int(11) DEFAULT NULL,
  `u_id` int(11) DEFAULT NULL,
  `cname` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `c_id` (`c_id`),
  KEY `u_id` (`u_id`),
  CONSTRAINT `t_topic_ibfk_3` FOREIGN KEY (`c_id`) REFERENCES `t_channel` (`id`),
  CONSTRAINT `t_topic_ibfk_4` FOREIGN KEY (`u_id`) REFERENCES `t_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_topic`
--

LOCK TABLES `t_topic` WRITE;
/*!40000 ALTER TABLE `t_topic` DISABLE KEYS */;
INSERT INTO `t_topic` VALUES (7,'给我一个爱这个世界的理由','时间|观点|创意|文艺|',1,1,'<p>方法实得分实得分</p>\r\n','',0,'2015-03-12 16:00:00','2015-03-13 11:41:23',7,1,'文章管理1','管理员'),(8,'悲伤的冰淇淋曲 ','文艺|悲伤|冰激凌|',1,1,'<p>1</p>\r\n\r\n<p>晨光明媚，临时搭建的帐篷绵延数十米。回辅大那天正好是游园会，到处熙熙攘攘。</p>\r\n\r\n<p>和我大学时代的场景并没有太大差别，校庆游园会本来就是各系的表演时间，法文系卖手工马卡龙，德文系卖啤酒，马来西亚学生社团卖咖喱&hellip;&hellip;还有食品科学系的冰淇淋，每年校庆都有&ldquo;特别口味&rdquo;，不知道今年的冰淇淋是什么口味呢？</p>\r\n\r\n<p>我看见那条漫长的队伍，终点似乎指向了冰淇淋贩卖处。不可避免地，我又想起了潘佑昕。这条等待冰淇淋的队伍像是通了电，那些藏在暗处的东西突然被明晃晃地点亮，刺痛我的双眼。<br />\r\n&nbsp;<br />\r\n2</p>\r\n\r\n<p>潘佑昕是我大学时代最后一任女友。<br />\r\n现在回想起来，和潘佑昕的爱情，能抓住的回忆片段，大都与吃脱不了关系。刚和她在一起的时候，食科系自己推出的冰淇淋不温不火，也没想到潘佑昕会让它一夜爆红。</p>\r\n\r\n<p>最初冰淇淋就有自己的贩卖处，一间小木屋，在我们外语学院旁边，下课的时候我从走廊探出身去，就能看见潘佑昕在不在里面。学校不求盈利，连小木屋都不需要租金，这种病态的宽容让经营有了几分玩闹的意味。<br />\r\n但我从第一天就知道，像潘佑昕那么要强的女生，绝对不会这么轻易放过冰淇淋。</p>\r\n\r\n<p>潘佑昕两眼放光：&ldquo;艺术家可以创作流芳千古的绘画雕刻，作家可以写不朽的文章，唯独食物，存在的时间那么短暂，但却拥有绘画书籍所没有的使命感。&rdquo;那时候我正在苦读哲学，听到这话，觉得潘佑昕像女神一般光芒四射，一时间竟无言以对。</p>\r\n\r\n<p>她把胸一挺：&ldquo;我已经做好了把这一生献给食物的准备。&rdquo;</p>\r\n\r\n<p>我的脑海里闪过了无数热血的画面，刀光剑影电闪雷鸣，然后一碗巨大的拉面浮现在我的眼前&hellip;&hellip;原谅我有限的想象力没有办法勾勒那幅用食物拯救世界的画面，但是从那一刻起，我对潘佑昕简直迷恋得无法自拔。</p>\r\n\r\n<p>隔天我就去买了一支冰淇淋，但说实话，那味道普通得让我在吃完它的一瞬间就再也想不起来自己买的是什么口味，或者它根本就没什么口味。</p>\r\n\r\n<p>潘佑昕仍然激情四射，每天吃饭的时候，她都把热情放在了对每一口食物的点评和分析上，猪排炸得太老，红豆饼的馅太甜，生鱼片切得不够功夫，炒牛河里的鸡肉不够入味&hellip;&hellip;我实在不忍再吃下去，那短短的一个月我收获到服务生相送的白眼可以撑起半边天。</p>\r\n\r\n<p>但我实在喜欢潘佑昕对着食物认真的样子，她一激动就会用手扯扯自己的耳垂，仿佛见到久违的仇人一样，恨不得上去决一死战。</p>\r\n\r\n<p>和潘佑昕的恋爱生活因为她对食物&mdash;&mdash;或者说对冰淇淋的过度沉迷，成了件很平静的事情。她没课的时候都在冰淇淋小木屋里捣鼓，在一起的第一个月刚过，我忍不住开玩笑说：&ldquo;我们简直天天像在小木屋度假。&rdquo;</p>\r\n\r\n<p>潘佑昕头也没抬：&ldquo;你再忍忍嘛，现在是非常时刻。&rdquo;<br />\r\n我听完，掏钱从她手里又买了支冰淇淋，咬了一口，还是那个味道。<br />\r\n潘佑昕说：&ldquo;我快要研发出新的口味了！成功了就陪你去逛街！逛三天三夜！&rdquo;<br />\r\n我：&ldquo;&hellip;&hellip;&rdquo;<br />\r\n&nbsp;<br />\r\n3</p>\r\n\r\n<p>校庆前一天的小木屋里，摆在我面前的有三个选择：豆浆红枣、绿茶蜂蜜、玫瑰草莓。<br />\r\n我非常认真而深情地看着佑昕的双眼，那是一双通红的眼睛，熬了许多的夜，就为了摆在我面前的这三个口味。</p>\r\n\r\n<p>我注视着她，希望让她明白她男朋友很心疼，并且正在从这三个杰作中做艰难的抉择，但佑昕却对我露出了非常怜悯的微笑，就是实验室的笨学生对着笼子里的小白鼠那副样子。</p>\r\n\r\n<p>我说：&ldquo;我选玫瑰草莓。&rdquo;<br />\r\n佑昕一听，拍了个巨响的掌，恍惚间我还以为她赏了我一耳光。<br />\r\n她说：&ldquo;好！玫瑰草莓，另外两种口味待会儿再试！&rdquo;<br />\r\n我说：&ldquo;会拉肚子吧&hellip;&hellip;&rdquo;</p>\r\n\r\n<p>我话还没说完，佑昕就用通红的眼睛狠狠瞪了我一眼，然后递过来一支颜色深红的冰淇淋。我看着那冰淇淋，觉得她一定在里面下了毒，从她瞬间变得热情的眼神里我已经看见了白雪公主的后妈。</p>\r\n\r\n<p>我咬了一口，甜。我把它咽了下去，草莓的香气猛地蹿上来，我瞪大眼睛。</p>\r\n\r\n<p>佑昕坐在我对面，露出了满意的表情。我又咬了一大口。她开始啧啧啧地摇起头来：&ldquo;这么好吃的东西，你居然用咬的，太浪费了，一点欣赏的品味都没 有。&rdquo;然后，她给自己也来了一支玫瑰草莓冰淇淋，优雅地吃了起来。我看着佑昕吃，她脸上带着喜悦又放松的样子，阳光照进小木屋里，要是落在她身上一定很 美。她说：&ldquo;好吃吧。&rdquo;语气不容置疑。</p>\r\n\r\n<p>我猛地点头。佑昕掏出手机，拨通电话：&ldquo;小陈啊你好，我是佑昕，今天早上说的那张海报先印五十张就行啦，旗子啊，五十面&hellip;&hellip;&rdquo;</p>\r\n\r\n<p>她讲着电话，盯着我笑，脸上的愉悦掩饰了淡淡的疲惫。<br />\r\n&nbsp;<br />\r\n第二天早上我下楼的时候，看见楼下廊道的每根柱子都贴上了巨幅海报，&ldquo;冰淇淋&rdquo;三个字闪闪发光，&ldquo;首次推出&rdquo;、&ldquo;特别口味&rdquo;、&ldquo;限量发售&rdquo;这些字张牙舞爪地印在海报上。佑昕果然不会放过冰淇淋，这海报做得跟通缉令似的。</p>\r\n\r\n<p>事实证明我眼光不错，玫瑰草莓口味不到一个钟头就最早销售一空，队伍排到校道上，食品科学系的同学估计也没见过这么大阵势，临时研究贩卖方案，居然开始摇号了。</p>\r\n\r\n<p>佑昕和她们系的女孩子们穿着女仆装站在小木屋门口当服务生，成功吸引无数眼球。佑昕老远看见我，兴奋地朝我挥手，引得众人对我侧目，看着她开心的样子，那一刻我却终于觉得她是我的女朋友了。</p>\r\n\r\n<p>校庆日之后，夏日的温度一天比一天高，冰淇淋的生意越来越好，每天从外语学院二楼的走廊望过去，佑昕总是在里面忙碌。</p>\r\n\r\n<p>那天晚上下课，我去小木屋，其他人都已经走了。</p>\r\n\r\n<p>佑昕看见我，什么也没说，转过身去从冰淇淋机里挤出了最后一支玫瑰草莓递给我。<br />\r\n我接过冰淇淋，说：&ldquo;我们什么时候才能多出去约点儿会呢？&rdquo;<br />\r\n她说：&ldquo;很快。&rdquo;<br />\r\n我故意装出落寞的样子说：&ldquo;冰淇淋才是你的男朋友啊，我只是小三。&rdquo;</p>\r\n\r\n<p>佑昕显然一眼看穿了我，她没有说话，从柜台后面绕出来，走到我面前，轻轻地咬了一口我手里的冰淇淋，踮起脚，在我嘴上亲了一下。我察觉嘴唇有种晶莹的凉意，在夏天的夜晚传遍全身，她轻声说：&ldquo;甜吗？&rdquo;</p>\r\n\r\n<p>我说：&ldquo;不仅甜，还酥。&rdquo;<br />\r\n&nbsp;<br />\r\n4</p>\r\n\r\n<p>如果爱情就是这样，那其实和这世界上的花花草草也没有什么区别，不过是平淡无奇地活在芸芸众生里。夏天来临之后，冰淇淋团队来了很多新人，冰淇淋的口味变得多种多样起来，佑昕也不那么忙了。</p>\r\n\r\n<p>从台南来台北念书，佑昕做好了毕业之后留在台北的准备，我心想这样也好，都留在台北就不用考虑毕业分手的事情了。我不是绝情的人，但大多数时候我知 道自己是个现实的人，就像我在佑昕的终日教育下，仍旧没办法对食物产生感情，在我眼里，它们就是以食物的意义存在的，在这点上，佑昕对我很无奈。</p>\r\n\r\n<p>临近毕业的时候，她爸爸来看过她一次。那天晚上我们三个人坐在餐厅里，佑昕和她爸爸坐在一起，中间隔着热气腾腾的火锅，升腾而起的水雾让我看不清他们的脸庞。</p>\r\n\r\n<p>佑昕和她爸爸说，毕业了就工作，等挣钱了把他接到台北来住，我正忙着往锅里下羊肉，听到这话的时候很平静。</p>\r\n\r\n<p>她还说要开一家冰淇淋餐厅。她爸爸似乎并不在乎佑昕要做什么，只是不断叮嘱她要照顾好自己，佑昕很开心，给她爸爸夹了很多肉。</p>\r\n\r\n<p>吃完饭的时候，佑昕的爸爸趁着佑昕上洗手间，突然对我说：&ldquo;拜托你了。&rdquo;</p>\r\n\r\n<p>我有些惊惶，一时间不知道该接什么话，只能一个劲点头让他放心。他对我笑，是非常沧桑而无奈的那种笑，我心里很不是滋味，总觉得佑昕的爸爸话里有话。<br />\r\n&nbsp;<br />\r\n5</p>\r\n\r\n<p>毕业前的日子阳光都好得不像话，我却无所事事又心烦意乱。</p>\r\n\r\n<p>我万万没有想到的是，佑昕居然随着毕业大军不辞而别了。</p>\r\n\r\n<p>我百思不得其解，无论如何，我绝不是混蛋东西，更没做出任何对不起潘佑昕的事情，何况征兆全无，佑昕就这样消失在空气里。</p>\r\n\r\n<p>她租在校外的房子留下一地的废纸和空袋子。我去了小木屋，结果看到的都是陌生的面孔，他们只对我错愕地摇头，我在小木屋绝望的表情吓到了那些工作人员，他们非常惊恐地望着我，不敢作声地看我摔门而去。</p>\r\n\r\n<p>所有的一切就像是开了个巨大的玩笑，只留下哈哈的笑声在耳边回荡。佑昕的电话已经打不通，很快，我更绝望地发现她所有的联系方式都把我拉黑了。</p>\r\n\r\n<p>整个世界天旋地转，我回到寝室摔了那只用了四年的陶瓷杯，一地的碎片吓得我室友站在门口目瞪口呆。我忽然想起什么就夺门而出，去找她同学，零零星星的消息告诉我，佑昕回台南了。</p>\r\n\r\n<p>我实在不能想象前一天还在和我满心激动地规划着创业和未来的女孩就这样绝情地走了。那天下午我坐在路边，给她打了几百个电话，通通被转进了语音信箱。</p>\r\n\r\n<p>不辞而别这么狗血的事情原来是真的会发生的，那一刻我忽然觉得，没有什么东西是永恒的，再好看的花都会谢，再美味的冰淇淋都会化，再爱的人都会走。真是讽刺，我居然会感慨。更讽刺的是，佑昕居然连个理由都没有给我。</p>\r\n\r\n<p>那一晚是我这辈子第一次失眠，凌晨三点钟我翻身下床，坐在电脑前给佑昕写了一封电子邮件，发到她的邮箱，那也是我和她仅存的唯一联系方式。</p>\r\n\r\n<p>看着小小的邮件图标和&ldquo;发送成功&rdquo;几个字，我觉得眼前一片浑浊，在书桌前坐到天亮。闹钟响起来的时候，起身去刷牙洗脸，回到房间爬上床的时候突然非常疲惫，眼睛干涩疼痛，室友欲言又止，我还没来得及躺好就睡过去了。<br />\r\n&nbsp;<br />\r\n6</p>\r\n\r\n<p>这次回母校是充当青年论坛的工作人员，每年游园会都是一年酷暑的开端，我西装里面的后背都湿透了。上午的论坛一结束，我就匆匆忙忙从医学院的报告厅跑出来，判断了一下方位，朝着小木屋走过去。</p>\r\n\r\n<p>队伍一点变短的意思都没有，骄阳当空，我把外套脱下来，排到队伍里。宣传冰淇淋的各色旗帜在风里轻柔地摆动着，食科系的工作人员服装统一，有个小学妹满脸笑容地来到我跟前：&ldquo;你要挑选什么口味呢？&rdquo;</p>\r\n\r\n<p>我礼貌地一笑：&ldquo;有什么口味？&rdquo;<br />\r\n小学妹挺直身板：&ldquo;今年的特别口味有三种：鳄梨牛奶、芒果脆饼，还有玫瑰草莓。&rdquo;<br />\r\n我愣住了：&ldquo;有玫瑰草莓？&rdquo;<br />\r\n小学妹认真地点头：&ldquo;是啊，你要试试吗？&rdquo;<br />\r\n我点头。小学妹从手拎的布包里取出了一张名片大小的卡片：&ldquo;纪念卡片哦。&rdquo;</p>\r\n\r\n<p>卡片上是手绘的一支冰淇淋，被几朵玫瑰花环绕，还盖了一个&ldquo;校庆特别口味&rdquo;的章。队伍前进，我拿着那张卡片，不知道即将到来的玫瑰草莓会是什么味道。</p>\r\n\r\n<p>付完钱，有个瘦高的男孩在我的卡片上剪了个洞，另一个男孩递给我一支颜色深红的冰淇淋。因为小木屋空间太小，冰淇淋贩卖机被搬到了屋外，我接过冰淇淋的时候，阳光火辣辣地照在我的脸上。</p>\r\n\r\n<p>我咬了一口，甜。</p>\r\n\r\n<p>我把它咽了下去，是草莓的味道&hellip;&hellip;味道，我苦笑了一下，本想对比多年前的那支玫瑰草莓冰淇淋是不是一样的味道，结果才发现自己根本就想不起来曾经的滋味了，还信誓旦旦地以为味蕾记得，没想到是过分信任它了。</p>\r\n\r\n<p>我又咬了一大口，脑海里一闪而过佑昕当年的责怪，我真是一点没变，一点欣赏的品味都没有。离开小木屋很远了，我知道不可能不想起佑昕，便干脆放任思绪游走。<br />\r\n&nbsp;<br />\r\n7</p>\r\n\r\n<p>我记得和佑昕最后的联系是一封电子邮件，从那之后我就再也没有收到来自她的任何信息了。她走之后，我等了很久，终于等来了她那封回信。</p>\r\n\r\n<p>她在信里说，不辞而别是不得不做的事情，她需要回到她爸爸身边。</p>\r\n\r\n<p>&ldquo;我会成为你的累赘，&rdquo;佑昕在信里写，&ldquo;但我最不喜欢的事情就是成为多余的人。&rdquo;</p>\r\n\r\n<p>我不知道她哪里来的结论，所谓&ldquo;累赘&rdquo;像是个勉强的借口，简直漏洞百出，我无处发泄，那我呢？我算什么？凭什么佑昕能轻描淡写地用这样的借口就把我打发了！</p>\r\n\r\n<p>我又记起佑昕爸爸吃完火锅的那晚，话里有话，有点托付的意味，可惜那个时候的我还是个毛头小孩，什么也没有读出来，惶恐得不能说话估计也让他失望了。</p>\r\n\r\n<p>直到他病重，佑昕都不知道自己的父亲发生了什么，她最不能原谅的，恰恰是这样的事情，自己居然在父亲那里也成了&ldquo;多余&rdquo;的存在，让佑昕崩溃了。</p>\r\n\r\n<p>&ldquo;我要回去，让他知道，他越是想让我走远越是不想给我添麻烦，我就越是不走。&rdquo;</p>\r\n\r\n<p>当年毕业当口，周遭的人兵荒马乱，我自以为镇定地告诉佑昕，如果她要我陪她留在台北创业，我就留下来和她一起奋斗，绝无二话；如果她等得起，我就去欧洲溜达两年。</p>\r\n\r\n<p>她微微一笑，说，我当然等得起。</p>\r\n\r\n<p>我自以为了解佑昕，几年时间好像彼此都一清二楚，到最后才发现自己还是个白痴，不懂得佑昕说出那句&ldquo;我当然等得起&rdquo;的时候，心里已然空荡荡。</p>\r\n\r\n<p>我最终决定不去欧洲。<br />\r\n可惜的是，还没有来得及把这个决定告诉佑昕，她就不辞而别了。</p>\r\n\r\n<p>还是慢了那么一点点，就因为差了这一点点时间，佑昕已经心灰意冷地回到她爸爸身边，独自一人面对接下来将要发生的一切。而那一切，曾经都是我以为要陪她共同面对的。</p>\r\n\r\n<p>不知道佑昕还记不记得她说过：&ldquo;我已经做好了把这一生献给食物的准备。&rdquo;</p>\r\n\r\n<p>她在那个夏夜把最后一支玫瑰草莓递给我的时候，我也以为自己做好了准备，但其实我是那么手忙脚乱不知所措。</p>\r\n\r\n<p>有些事情一旦错过，就再也没有机会去弥补了，不管你愿意付出多少努力，都不可能重新来过。佑昕匆匆忙忙在我最好的青春里走了一场，用一个决绝的转身画上了句号，告诉我故事都会讲完，要懂得为一切可能的结局做好准备。<br />\r\n&nbsp;<br />\r\n8</p>\r\n\r\n<p>潘佑昕后来可能又回到台北，开了那间她始终念念不忘的冰淇淋餐厅。</p>\r\n\r\n<p>父亲去世之后，佑昕就只身一人了吧。</p>\r\n\r\n<p>回过神来，冰淇淋在阳光里化掉了，滴到我的手上，像鲜红的血。</p>\r\n\r\n<p>冰淇淋的存在是短暂的，任何一支冰淇淋都没有办法成为不朽的杰作，但我相信，制作冰淇淋那片刻的心情，是可以永存的。</p>\r\n\r\n<p>虽然我到现在都未能非常理解佑昕离开时的心情，对我来说，那种突如其来的不辞而别，除了是对我的惩罚，再无其他理由，让我不悦和痛苦，能不想起我就绝不再回忆。</p>\r\n\r\n<p>但我也渐渐明白，花会谢，冰淇淋会化，爱的人会离开，可能确实不为什么，只是本来就会发生的事情，我们能做的，就是做好迎接它们到来的准备。</p>\r\n\r\n<p>而有些回忆，像潘佑昕很多年前做出的第一支玫瑰草莓冰淇淋，在夏天的夜晚里，终于变成了一支悲伤的曲子，回荡在很多年后我的心头。</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>黄可，90后写作者。@黄黄黄可&nbsp;</p>\r\n','但我也渐渐明白，花会谢，冰淇淋会化，爱的人会离开，可能确实不为什么，只是本来就会发生的事情，我们能做的，就是做好迎接它们到来的准备。 ',0,'2015-03-12 16:00:00','2015-03-13 11:47:14',10,1,'文章管理4','管理员'),(16,'fgfd','悲伤|时间|',0,1,'<p>gfdg</p>\r\n','fg',0,'2015-03-12 16:00:00','2015-03-13 13:03:51',8,1,'文章管理2','管理员'),(18,'无从告别的告别 ','告别|离殇|伤感|',1,1,'<p>1<br />\r\n小时候我常常面对离别。</p>\r\n\r\n<p>大人会跟我说，明天我们要去xx地方了。而xx地方，一般都是我从未听说过的某个城市。我听完会默默地点头，然后坐在沙发上，看大人们收拾东西。心里则提前开始消化恐慌，对未知和陌生的恐慌。</p>\r\n\r\n<p>记得还在上海的时候，小区里住着许多子女不在身边的孤寡老人，老师要我们在某个暑假去找一个老人，然后陪伴他们，算是作业。</p>\r\n\r\n<p>我就找了隔壁那幢楼的一个老头。我记得我第一次敲他的门，他开了半截门，奇怪地看着我，我呆滞地傻愣半天，然后用手摇了摇胸前的红领巾说：&ldquo;你好，我是小学生。老师要我来陪你。&rdquo;</p>\r\n\r\n<p>老头听完，微微一笑，把门敞开，示意我进去，问我：&ldquo;你从哪里来？&rdquo;</p>\r\n\r\n<p>我坐在脚碰不到地的高凳上，晃动着双脚指了指左边说：&ldquo;我从隔壁来。&rdquo;</p>\r\n\r\n<p>&ldquo;嗯，我见过你，每天带着一帮小朋友到处折断小区里的竹子。&rdquo;</p>\r\n\r\n<p>我点点头说：&ldquo;没错！&rdquo;</p>\r\n\r\n<p>他又问我：&ldquo;为什么？&rdquo;</p>\r\n\r\n<p>&ldquo;为了赶一只猫和打仗。&rdquo;</p>\r\n\r\n<p>他笑笑没理我，打开了大厅和天井之间的门，我抬头看去，天井里全是花花草草和无数个鸟笼，每个鸟笼里都住着一只鸟。</p>\r\n\r\n<p>我站起身准备接受他的邀请一起走进天井里看看。但是他没有。他就那么自顾自旁若无人地摆弄起了花草，让我觉得他不太懂人情世故，没有家教。</p>\r\n\r\n<p>搞得我有点不知所措，只能又坐回原处，开始四下张望。</p>\r\n\r\n<p>老头家里有简单的家具，一堆茶壶，一张大桌子上有一盏式样老土的彩色玻璃灯，灯旁有很多农业技能书。我想尝试跟他对话。</p>\r\n\r\n<p>于是对他&ldquo;喂&rdquo;了一声。</p>\r\n\r\n<p>他转过头来说我没礼貌，然后又继续低头在天井里摆弄花草。</p>\r\n\r\n<p>最后我只能哈欠连天地看着墙上的表，等着两个小时结束。</p>\r\n\r\n<p>因为那时老师规定我们，每次陪老人家至少两个小时，然后拿一个小本子给老人家签字和写评语。</p>\r\n\r\n<p>临走的时候，我拿出本子给老头，老头戴上老花镜看了看本子上的大致内容，问我写什么好。这个问题让我猝不及防，觉得回到了从前&mdash;&mdash;考试考得好，老师放了一排礼物，让我们各自挑自己喜欢的，我喜欢最贵的，但常常不好意思直接拿，都是拿的退而求其次的奖品。</p>\r\n\r\n<p>于是我说：&ldquo;写点还不错的就行。&rdquo; 接着马上有点不好意思地看向别处。</p>\r\n\r\n<p>然后就听见了他刷刷写字的声音，写完合上本子递给了我。我拿起本子，转身要走。他又叫住了我，从天井里抱来一盆土：&ldquo;你在土上面摁一摁。&rdquo;</p>\r\n\r\n<p>我不解地看着他，他说：&ldquo;摁一摁就行！&rdquo; 我就摁了一摁，然后马上嫌弃地边搓手边走了出去。</p>\r\n\r\n<p>回到家，吃饭的时候，妈妈问我今天陪老爷爷开心吗，我说不开心，妈妈问我为什么，我说因为这老头不开心我陪他。</p>\r\n\r\n<p>妈妈一个筷子头打了过来，骂我没礼貌。</p>\r\n\r\n<p>我心里愤愤不平，边吃菜边开始在脑海里统计周围的老人家还有哪些，下定决心一定要换一个人陪陪。</p>\r\n\r\n<p>在那天临睡前，我突然想起那个本子，然后迫不及待地想看看老头写了什么内容，于是翻开看了看，发现上面工工整整地写着：&ldquo;他今天非常乖，非常热情，很有礼貌，家教很好，很讨人喜欢。&rdquo;</p>\r\n\r\n<p>那时我语文好，知道&ldquo;非常&rdquo;和&ldquo;很&rdquo;后面只要接上很好的词汇，就是很好的表扬。看完，竟然有点不好意思。</p>\r\n\r\n<p><br />\r\n2<br />\r\n后来我每天去陪这老头，几乎不怎么说话，他不是弄花草就是弄鸟，偶尔我坐在大厅和天井连接的地方，呆呆地着看他。</p>\r\n\r\n<p>老头则依旧每天结束时，在本子上换着花样夸我。得到他无比绚丽的措辞几乎成了我去陪他的唯一动力。从活泼，到善良，再到爱护花草，和学习能力强。应有尽有。</p>\r\n\r\n<p>某个下午老头坐在桌子上看书，我在他对面一动不动，老头抬头看了看我，然后看了看他那堆书。</p>\r\n\r\n<p>我就跟顺着他的目光也看了看那堆书，随后又继续呆滞地看着他，他又用手拨了拨他那堆书。</p>\r\n\r\n<p>我才看见里面有一本《杨家将演义》的连环画。我伸手摸了摸那本书，犹豫间，他对我点点头。于是我就把那本书抽了出来。津津有味地读了起来。</p>\r\n\r\n<p>老头问我最喜欢谁，我说我喜欢杨宗保。</p>\r\n\r\n<p>老头问我为什么。</p>\r\n\r\n<p>我说因为电视上他老婆穆桂英好看。</p>\r\n\r\n<p>他又问我喜欢花木兰吗，我问她花木兰是谁。他就给我讲了一下午花木兰。</p>\r\n\r\n<p>从那天起，他就不摆弄花草了，每次来，都和我面对面看书，每天他书堆里都会莫名其妙地有一本不同的连环画。</p>\r\n\r\n<p>有一天看到又是连环画，我突然觉得无聊透了，做作地打起了一个又长又大声的哈欠，然后趴在了桌子上一言不发地发呆。</p>\r\n\r\n<p>老头咳嗽了几声，然后问我吃糖吗。我继续趴在桌子上摇着头。</p>\r\n\r\n<p>他说你等一会，转身进了房间。我看见他打开衣柜，到处翻，最后面红耳赤地拿出一把剑。</p>\r\n\r\n<p>我立马跳了起来，双眼放光地看向他，因为我从小就喜欢大宝剑这种东西。</p>\r\n\r\n<p>老头第一次脸上露出了调皮的神色，拔出剑来，故作姿态地舞了两下。那天下午我们在天井里，老头教我玩了一套晨练时的老年剑法。</p>\r\n\r\n<p>从那天之后，我只要去到老头家，他会第一时间给我背上那把大宝剑，然后该干吗干吗。看书，陪他弄花草，他会问我很多关于我的事，有一天当他得知我在学校是大队长的时候，他直接把我抱了起来，一个劲地对我说：&ldquo;原来你这么厉害呀！&rdquo;</p>\r\n\r\n<p>我则得意地笑着。</p>\r\n\r\n<p>我跟老头没事就看书，弄花草，逗鸟，和玩大宝剑，不知不觉过去了15天，还有5天我就可以结束陪伴老人家的作业了。</p>\r\n\r\n<p>我把这件事告诉了老头，老头愣了一会，说：&ldquo;那明天我带你去城隍庙买一把属于自己的大宝剑吧。&rdquo;</p>\r\n\r\n<p>我惊讶地看向他，问他是真的吗？</p>\r\n\r\n<p>他用力地点点头。我一激动，抱住了她，第一次说了句：&ldquo;谢谢爷爷！&rdquo;</p>\r\n\r\n<p>他 面色绯红，有点不好意思，也抱了抱我，但显得异常开心。那天晚上，他陪我一起回家，然后跟我的妈妈说他想第二天带我去城隍庙玩，希望我妈妈同意。然后还从 包里掏了很久，掏出自己的身份证，还有一张写了自己电话的纸片。他们在门口聊了挺久，而我在屋子里紧张地看着这一切。最后看见老头对我开心地笑了笑，用手 凭空作剑，对着我舞了舞，就开心地走了。</p>\r\n\r\n<p>妈妈转头过来严肃地看着我，我马上立正在原地，妈妈对我说：&ldquo;不能乱跑，知道吗？&rdquo;</p>\r\n\r\n<p>我一颗心就沉了下去。</p>\r\n\r\n<p>接着妈妈又说：&ldquo;在明天跟爷爷出去的时候。&rdquo;</p>\r\n\r\n<p>我立马喜笑颜开，脖子像按了发条，使劲点头。</p>\r\n\r\n<p>第二天在城隍庙，老头全程拉着我的手，他带我走进一个大楼里，里面有数不过来的摊位，每个摊位的墙上都挂满了大宝剑，我们两个这家看看，那家看看，人很多，很拥挤，我看见他有点不自然，把我护在他身前，挤到一个摊位前。</p>\r\n\r\n<p>看着琳琅满目的刀枪棍棒，我一时没了目标，满心欢喜地扫来扫去，我们两个站在一起，老头有些紧张地问我：&ldquo;是不是不喜欢这里的？&rdquo;</p>\r\n\r\n<p>我摇摇头说：&ldquo;没有，我都喜欢！&rdquo;</p>\r\n\r\n<p>老头才爽朗地笑了起来，告诉我别着急，慢慢挑，他等我。</p>\r\n\r\n<p>后来我挑了一把黑色的，老头找老板要了一根红色的背带，蹲在门口帮我按在了剑鞘上，挂上了我的后背。那天我觉得自己终于成为了我最想成为的人&mdash;&mdash;展昭。</p>\r\n\r\n<p>后来老头带我去买麦芽糖，我们坐在一个亭子里吃糖的时候，老头问我：&ldquo;你有爷爷吗？&rdquo; 我愣了好一会。</p>\r\n\r\n<p>他有点尴尬地看着我，显得不知所措。</p>\r\n\r\n<p>我反问他：&ldquo;爷爷是&hellip;&hellip;我爸爸的爸爸？&rdquo;</p>\r\n\r\n<p>他有点惊讶，接着对我说：&ldquo;是啊。&rdquo;</p>\r\n\r\n<p>我边吃糖边说：&ldquo;我不记得自己的爷爷，从来没有见过他。&rdquo;</p>\r\n\r\n<p>他就不说话了，摸摸我的头，问我说：&ldquo;你还想吃什么？&rdquo;</p>\r\n\r\n<p>我摇摇头，一起陷入了沉默里。</p>\r\n\r\n<p><br />\r\n3<br />\r\n其实我从小就不记得自己爷爷和所有亲戚，因为我的童年颠沛流离，一时在这，一时在那，却从未回过老家。</p>\r\n\r\n<p>我一直以为每年过年家里只有四个人，是很正常的事情。</p>\r\n\r\n<p>我一直到97年香港回归，7岁那年，才第一次听爸爸妈妈对我说起&ldquo;爷爷&rdquo;两个字。那是一个晚上，我从睡梦中被叫醒，带着一肚子的起床气，觉得自己恨整个世界。</p>\r\n\r\n<p>爸爸严肃地把我拉到角落里，让我穿上衣服，说要带我去见爷爷。我磨磨蹭蹭半天，就是不肯。因为那年我实在不知道爷爷是什么。对于到底哪里突然冒出了一个爷爷来，我百思不得其解，并且很认真地以为爷爷是爸妈的某个无聊朋友。</p>\r\n\r\n<p>后来爸爸接了一个电话，神色更加急迫，大声地吼我：&ldquo;你到底要不要穿衣服！&rdquo;</p>\r\n\r\n<p>我一肚子起床气瞬间找到了出口，哭声喷薄而出，大声地喊着：&ldquo;我就不穿！&rdquo;</p>\r\n\r\n<p>爸爸对我投来了一个此生难忘的失望眼神，然后和妈妈急匆匆地出门了。没过多久，一个称之为&ldquo;姑姑&rdquo;的人来到了家里，哄我哄了半天，我才把衣服穿上，跟着她出了门，去见所谓的&ldquo;爷爷&rdquo;。</p>\r\n\r\n<p>去到一半，姑姑接了一个电话，然后让司机掉转车头，我们又回了家。</p>\r\n\r\n<p>那天从头到尾我都不知道发生了什么。</p>\r\n\r\n<p>那之后的许多年，我才终于很清晰地知道了爷爷是谁，是干吗的，也从别人口中得知，我还没记事的时候，爷爷常常在过年的时候叫着我的小名，然后我屁颠屁颠地跑过去，他会塞给我一个无比丰厚的红包，别人说他最疼我，小时候。</p>\r\n\r\n<p>只是后来我被父母带着四处跑，既不知道自己根在哪，也不知道有哪些所谓的亲人，我以为世界上每个人都和我一样，只有家人。</p>\r\n\r\n<p>也知道了，那个晚上，是我最后一次，能见到爷爷的机会。此后这件事成了我想起一次就遗憾和自责一次的事情。</p>\r\n\r\n<p>直到去年我24岁，临近清明节的时候，爸爸让我开车带着姐姐回老家去给爷爷扫墓。我听完二话没说就推掉了所有事情。</p>\r\n\r\n<p>一路上雨点淅淅沥沥地打在车上，我和姐姐一路上都没有说话，开在乡间的泥泞小路上。</p>\r\n\r\n<p>我被亲戚带着，去了爷爷住过的老房子，看见一个黑不溜秋的奶瓶，他们说那是我的。看见了许多爷爷当年生活时的东西，甚至都叫不上名字，那到底是什么。</p>\r\n\r\n<p>那天在墓碑前，放起了一长串大鞭炮，我看着爷爷的名字，心里说：&ldquo;爷爷，我回来啦。&rdquo; 然后眼睛就红了。</p>\r\n\r\n<p>我心里又说：&ldquo;爷爷，在那个年纪，我真是像个不落地的蒲公英，从未有人跟我提过我从哪里来，也没有人确定地告诉我，我要到哪里去。&rdquo;</p>\r\n\r\n<p>就像被风一直裹着，以为世界上并没有可以落脚的土地。</p>\r\n\r\n<p>&ldquo;但你原谅我的话，你就刮来一阵风好了。&rdquo;</p>\r\n\r\n<p>于是那天很神奇地在一秒之后，刮来了一阵风。</p>\r\n\r\n<p><br />\r\n4<br />\r\n后来在那个陪老人的作业本上，老爷爷给我写的最后一个评语是：&ldquo;他像我的孙子一样，我像他的爷爷一样。&rdquo;</p>\r\n\r\n<p>那时我常常面对离别，妈妈在某天跟我说，这个暑假结束之后，我们要去重庆了。</p>\r\n\r\n<p>我点点头，坐在沙发上。我不知道重庆是什么地方，也不知道在那会遇见什么人。只是已经开始在心里提前默默地消化起了对未知和陌生的恐惧。</p>\r\n\r\n<p>走那天，老头赶来，抱着一盆小花，气喘吁吁地说：&ldquo;这是你来那天，我给你种的，名字就叫小则林。&rdquo;</p>\r\n\r\n<p>我一看是一盆黄黄的小花。</p>\r\n\r\n<p>但妈妈说：&ldquo;坐飞机，带不了这些。&rdquo;</p>\r\n\r\n<p>我遗憾地看着老头，老头也略显无奈，犹豫了一会说：&ldquo;没事，等你回来的时候，小则林就跟你长得一样大了。&rdquo;说完摸了摸我的头。</p>\r\n\r\n<p>但我并没有再回来过，甚至没能带走那把爷爷送我的大宝剑。</p>\r\n\r\n<p>并且那年，最后走的时候，我也没明白过来，&ldquo;爷爷&rdquo;到底是什么。</p>\r\n\r\n<p>但只要时间一天一天地过去，人在时间里，很快就会长大。</p>\r\n\r\n<p>有时夜深人静的时候，我会想起那盆小黄花，也会想起97年那个夜晚。</p>\r\n\r\n<p>并且每次都带着遗憾，因为他们从来不知道我去了多少地方，也不知道我见过多少人，甚至他们永远没有办法知道，他们一直在我心里，并且没有办法告诉他们，这些无从告别的告别。</p>\r\n\r\n<p>（责任编辑：金子棋）</p>\r\n','我不知道重庆是什么地方，也不知道在那会遇见什么人。只是已经开始在心里提前默默地消化起了对未知和陌生的恐惧。 ',0,'2015-03-12 16:00:00','2015-03-13 14:14:22',10,1,'文章管理4','管理员');
/*!40000 ALTER TABLE `t_topic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_user`
--

DROP TABLE IF EXISTS `t_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `nickname` varchar(200) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_user`
--

LOCK TABLES `t_user` WRITE;
/*!40000 ALTER TABLE `t_user` DISABLE KEYS */;
INSERT INTO `t_user` VALUES (1,'guanly','aa039fd82d6d0b1735434afc65a3698e','管理员','110','admin1@admin.com',1,'2010-12-11 16:00:00'),(2,'admin2','7bde05b5fdaa4919faebdf3b110cc904','文章发布人员','110','admin1@admin.com',1,'2010-12-11 16:00:00'),(3,'snow','1794044e2bab8f0199937f4927455cf5','高国祥','15895274874','snowxuyu@126.com',1,'2015-03-11 08:27:21');
/*!40000 ALTER TABLE `t_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_user_group`
--

DROP TABLE IF EXISTS `t_user_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_user_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `u_id` int(11) DEFAULT NULL,
  `g_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `u_id` (`u_id`),
  KEY `g_id` (`g_id`),
  CONSTRAINT `t_user_group_ibfk_1` FOREIGN KEY (`u_id`) REFERENCES `t_user` (`id`),
  CONSTRAINT `t_user_group_ibfk_2` FOREIGN KEY (`g_id`) REFERENCES `t_group` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_user_group`
--

LOCK TABLES `t_user_group` WRITE;
/*!40000 ALTER TABLE `t_user_group` DISABLE KEYS */;
INSERT INTO `t_user_group` VALUES (9,5,2),(10,6,1),(11,6,2),(12,6,3),(13,3,1),(14,3,2),(15,3,3);
/*!40000 ALTER TABLE `t_user_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_user_role`
--

DROP TABLE IF EXISTS `t_user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_user_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `u_id` int(11) DEFAULT NULL,
  `r_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `u_id` (`u_id`),
  KEY `r_id` (`r_id`),
  CONSTRAINT `t_user_role_ibfk_1` FOREIGN KEY (`u_id`) REFERENCES `t_user` (`id`),
  CONSTRAINT `t_user_role_ibfk_2` FOREIGN KEY (`r_id`) REFERENCES `t_role` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_user_role`
--

LOCK TABLES `t_user_role` WRITE;
/*!40000 ALTER TABLE `t_user_role` DISABLE KEYS */;
INSERT INTO `t_user_role` VALUES (19,1,1),(20,2,2),(21,5,3),(22,3,2),(23,3,3);
/*!40000 ALTER TABLE `t_user_role` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-03-16 16:33:25
